## terminal-plotter

terminal-plotter is a python module used to plot image in terminal.

